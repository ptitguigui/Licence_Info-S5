% Q5
fdsQ5([ [[a,b],[c]], [[b,d],[e,f]],[[b],[f]],[[f],[g,h]],[[d],[i,j]] ]).

% clé de R
% schemaQ4(R), fdsQ5(F), superkey(R,F,K).
% Résultat: false

% 3NF de R
% schemaQ4(R), fdsQ5(F), threenf(R,F,R3NF).
% Resultat : false
schema([a,b,c,d,e]).
fds([[[a],[b,c]], [[b],[a]], [[a,b],[d]], [[a],[d]], [[b,c],[a]]]).

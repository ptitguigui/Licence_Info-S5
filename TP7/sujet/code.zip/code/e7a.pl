schema([a,b,c,d,e]).
fds([[[a],[c]], [[b],[c]], [[c],[d]], [[d,e],[c]], [[c,e],[a]]]).
decomp([[a,d],[a,b],[b,e],[c,d,e],[a,e]]).
